
// Fungsi untuk membuka proyek Figma
function bukaProyek1() {
    window.open(
        "https://www.figma.com/proto/I3KUrzEhMMUWX8Mda8hOm2/T5Figma_PTI-B_682026058?page-id=0%3A1&node-id=9-880&p=f&viewport=-115%2C87%2C0.26&t=UvCG296cBU3MDcsT-1&scaling=scale-down&content-scaling=fixed",
        "_blank"
    );
}

// Fungsi untuk membuka proyek 3
function bukaProyek3() {
    window.open(
        "https://drive.google.com/file/d/1Bp5Ig8lEwR-Z0Hms-Tmb0-iYVbL4mAan/view",
        "_blank"
    );
}
